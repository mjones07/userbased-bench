from setuptools import setup

setup(
    name='userbased_nc_bench',
    version='0.1',
    scripts=['userbased_nc_bench']
)
